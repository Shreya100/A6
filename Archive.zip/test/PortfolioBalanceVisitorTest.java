import org.junit.Before;
import org.junit.Test;

/**
 * JUnit tests for Visitor class .
 */
public class PortfolioBalanceVisitorTest {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void apply() {
  }
}